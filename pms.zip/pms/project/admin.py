from django.contrib import admin
from.models import *

# Register your models here.
admin.site.register(Project)
admin.site.register(Projet_team)
admin.site.register(Status)
admin.site.register(Project_module)
admin.site.register(Task)
#admin.site.register(user_task)